export * from './cadastro-pj.model';
