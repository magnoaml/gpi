export * from './cadastro-pj.service';
